#!/bin/bash
##############################################################
#Script Name: common.sh
##############################################################
#output green tip
function puts() {
	echo -e "\033[32;49;1m$1\033[39;49;0m"
}

#complier
#complier_pkg() purpose: complier the *.tar.gz pakecages
#$1: path ; $2 software name; $3 complier parameters,
path_trash=/dev/null

#error_code() purpose: according the result of the function 'copy_file()',return the error info.
function error_code()
{	
	#0x0001:Parameter is too much or too little
	if [ "$1" == "0x0001" ]; then
		puts  "Error 0x0001: Parameter is too much or too little,Please check the input parameters. "
		puts  "The	total parameters of this function is 4, current number is : '$2'. "
		puts  "Param1: the source path , for example : /root/Desktop/Mydocs."
		puts  "Param2: the source file , for example : src_file1 ."
		puts  "Param3: the destination path , for example : /var/www/backup."
		puts  "Param4: the destination file , for example : dst_file2."
	fi


	#0x1001: The parameter contains illegal characters
	if [ "$1" == "0x1001" ]; then
		puts  "Error 0x1001: The parameter contains illegal characters~! "
		puts  "The para should not include . "
		puts  "Please check the parameter: '$2' "
	fi

	#0x1002: The file path does not exist;
	if [ "$1" == "0x1002" ]; then
		puts  "Error 0x1002: Path does not exist~! "
		puts  "Please check the path : '$2'. "
	fi
	
	#0x1003: File does not exist;
	if [ "$1" == "0x1003" ]; then
		puts  "Error 0x1003: File does not exist~! "
		puts  "Please check file '$2/$3' . "
	fi 
}

#copy_file() purpose: copy the file from one place to another place.
function copy_file()
{
	#1. Check the the number of parameters 
	#puts $#
	#puts $*
	if [ $# -lt 4 ]; then
		#puts "Parameter is too much or too little !"
		error_code 0x0001 $#
		exit
	fi

	#2.Check the parameter format
	#Use regular expressions inspect the path format and file name
		
	#3 Check the the existence of the source path and file
	#3.1 Check the source path ,
	if [ ! -e $1 ]; then		
		#puts "The file path does not exist !"
		error_code 0x1002 $1
		exit
	fi

	#3.2 Check the source file 
	if [ ! -e	$1/$2 ]; then
		puts  "Copying, source file does not exist !"
		error_code 0x1003 $1 $2
		exit
	fi

	#4 Check the destination path 
	if [ ! -e $3 ]; then
		#puts "File does not exist !"
		error_code 0x1002 $3
		exit
	fi	

	#5 Delete the backup files
	num=`( ls $3/$4.bak* 2>&1 >/dev/null | wc -l )`
	if [ $[num ] -ge 1 ]; then
		#puts "Delete backup file(s)."
		rm -f $3/$4.bak*
	fi
	
	#6.Check the destination file,if it exists ,then backup
	if [ -e	$3/$4 ]; then
		#puts "The destination have had this file."
		mv	$3/$4 $3/$4.bak_$(date +%F)
	fi
	
	#7.Do copy, convert file format, change file access permissions 
	#7.1	Copy the file
	cp $1/$2 $3/$4
	if [ $? == 0 ];then
		puts "OK: Copy configuration file '$1/$2' to '$3/$4' successfully."
	else
		puts "Fail: Copy configuration file '$1/$2' to '$3/$4 failure.'"
	fi
	#7.2 Convert file format: from DOS/MAC to UNIX
	dos2unix $3/$4
	#7.3 Change file access permissions
	chmod 755 $3/$4	
}

#config_service() purpose: configure service running-level,start and check service status
function config_service()
{
	if [[ $#  -ne 1 ]]; then 
		puts "Too many or too few parameters:"
		exit 1
	else
		:
	fi
	
	puts "Configure service '$1' running-level "
	chkconfig $1 on
	chkconfig --list |grep $1

	puts "Start service '$1' and check running status."
	service $1 start
	service $1 status
	ps -ef |grep $1
}

#check_service() purepose: Use 'service' command to check service running status
function check_service()
{
	service $1 status >> /dev/null 2>&1
	#puts "Check service '$1' running status:"
	if [ $? == 0 ]; then
		puts "OK: Service '$1' is running."
	else
		puts "Fail: Service '$1' is not running,please check..." 
        fi
	puts
}

#check_result() purepose: The format for output result.
function check_result() 
{
	puts "#========================================================================="
	puts "#Date: $(date +%F) $(date +%T)"
	puts "#Scripts: /etc/scripts/check_service.sh $1"
	puts ""
}

#check_pkgs_installed() purpose: Use 'rpm' command to check packages installed. 
function check_pkgs_installed()
{
	if [[ $#  -ne 1 ]]; then 
		puts "Too many or too few parameters:"
		exit 1
	else
		:
	fi

	puts -e "\nCheck '$1' ..."
	rpm -qa |grep $1 |sort -d
}

#check_ql() purpose:
function check_ql(){
	#puts -e "\n===CHECK ql locate=== ..."
	puts -e "\nCheck '$1' configuration ..."
	if [[ $#  -ne 1 ]]; then 
		puts "Too many or too few parameters:"
		exit 1
	else
		#puts -e "\nCheck service '$1'"
		updatedb
		locate $1/$1.conf
		locate $1/conf
		puts 
	fi
}

#run_service() purpose: Use 'service' to run (start|stop|restart|status) service.  
function run_service()
{
	if [[ $#  -ne 2 ]]; then 
		puts "Too many or too few parameters:"
		exit 1
	else
		:
	fi
	
	case $2 in
		1|start)
		service $1 start
		;;
		
		2|stop)
		service $1 stop
		;;
		
		3|restart)
		service $1 restart
		;;
		
		4|status)
		service $1 status >> /dev/null 2>&1
		if [ $? == 0 ]; then
			puts "OK: Service '$1' is running."
		else
			puts "Fail: Service '$1' is not running,please check..." 
		fi
		puts
		;;
		
		0|quit)
		exit
		;;
	esac
}
