#!/bin/bash
##############################################################
#Script Name: dpy_nginx.sh
##############################################################
#
base_path=/usr/local/src/auto-nginx
path_pkgs=$base_path/Packages
path_conf=$base_path/Conf
path_scripts=$base_path/Scripts
path_www=/data/www
path_init=/etc/rc.d/init.d
path_logs=/data/log

install_nginx_dir=/usr/local/nginx
etc_nginx=/etc/nginx
etc_nginx_confd=$etc_nginx/conf.d
ver_nginx=nginx-1.10.0
opt_nginx="--prefix=/usr/local/nginx \
--add-module=$path_pkgs/nginx-upload-module-2.2 \
--user=www \
--group=www \
--sbin-path=/usr/local/nginx/sbin/nginx \
--conf-path=/etc/nginx/nginx.conf \
--pid-path=/usr/local/nginx/run/nginx.pid \
--error-log-path=/data/log/nginx/error.log \
--http-log-path=/data/log/nginx/access.log \
--with-http_realip_module \
--with-http_stub_status_module \
--with-http_ssl_module \
--with-http_gzip_static_module \
--with-http_sub_module \
--with-http_slice_module \
--with-stream"

src_nginx_conf=nginx.conf
src_nginx_init=nginx_init

dst_nginx_conf=nginx.conf
dst_nginx_init=nginx

#uninstall() purpose: uninstall packages installed
uninstall_nginx()
{
	puts "Uninstall nginx packages"
	pid_num=`ps -ef|grep [n]ginx|wc -l`
	if [ ${pid_num} = 0 ];then
	        rm -rf /usr/local/nginx
	        rm -f /etc/init.d/nginx
	        rm -rf /etc/nginx/*
		rm -rf $path_www
	else
		puts "Stop nginx."
		run_service nginx stop
	        rm -rf /usr/local/nginx
	        rm -f /etc/init.d/nginx
	        rm -rf /etc/nginx/*
		rm -rf $path_www
	fi	
}
#pre_install() purpose: install packages before the process.
pre_install()
{
	puts "yum clean all"
	yum clean all

	puts "Install some useful tools"
	yum install -y dos2unix wget rsync inotify-tools unzip git
	
	puts "Install gcc"
	yum install -y libgcc gcc gcc-c++
	
	puts "set ldconfig"
	echo "/usr/local/lib64" > /etc/ld.so.conf.d/local.conf
	echo "/usr/local/lib" >> /etc/ld.so.conf.d/local.conf
	echo "/usr/lib64" >> /etc/ld.so.conf.d/local.conf
	echo "/usr/lib" >> /etc/ld.so.conf.d/local.conf
	ldconfig
	
}

#install_nginx() purpose: complier the nginx 
install_nginx()
{
		
	#Install depency packages
	puts "Install depency packages"
	yum install -y pcre pcre-devel zlib zlib-devel openssl openssl-devel
	puts "unzip nginx-upload-module-2.2.zip"
	cd $path_pkgs	
	unzip $path_pkgs/nginx-upload-module-2.2.zip
	if [ -d $path_pkgs/$ver_nginx ];then
		rm -rf $path_pkgs/$ver_nginx
	fi

	if [ -e $path_pkgs/$ver_nginx.tar.gz ];then
	    ls -l $path_pkgs/$ver_nginx*
		puts "Start install nginx..."
		tar -zxf $path_pkgs/$ver_nginx.tar.gz -C $path_pkgs/
		cd $path_pkgs/$ver_nginx
		./configure $opt_nginx
		make && make install
	else
		puts "$ver_nginx.tar.gz not exists."
		puts "Can do nothing."
		exit
	fi
}

#config_nginx() purpose: config nginx services.
config_nginx()
{
	#Disabled selinux
	sed -i 's/SELINUX=enforcing/SELINUX=disabled/g' /etc/sysconfig/selinux
	
	#Create web user
	groupadd www
    	useradd -s /sbin/nologin -g www www
	
	#Configure nginx
	mkdir -p $etc_nginx
	mkdir -p $path_www
	mkdir -p $etc_nginx_confd
	mkdir -p $path_logs/nginx
	mkdir -p ${install_nginx_dir}/run
	chown -R www.www  $path_www

	ln -sf /usr/local/nginx/sbin/nginx /usr/bin/nginx
	
	#Copy nginx main configurations
	copy_file $path_conf $src_nginx_conf $etc_nginx $dst_nginx_conf
	
	#Copy nginx init scripts
	copy_file $path_conf $src_nginx_init $path_init $dst_nginx_init

	#Config nginx run-level
	config_service nginx
}

#//////////////////////////Main Body //////////////////////////////////
source $path_scripts/common.sh
uninstall_nginx
pre_install
install_nginx
config_nginx
